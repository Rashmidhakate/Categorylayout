<?php

namespace CP\Categorylayout\Observer;

use Magento\Framework\Registry;
use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\Event\Observer;

class Categorylayout implements ObserverInterface
{
    const ACTION_NAME = 'catalog_category_view';

    /** @var Registry */
    private $registry;

    public function __construct(
        \Magento\Catalog\Model\CategoryFactory $categoryFactory,
        \Magento\Catalog\Model\ResourceModel\Category\CollectionFactory $categoryCollection,
        Registry $registry
    ) {
        $this->category = $categoryFactory;
        $this->_categoryCollection = $categoryCollection;
        $this->registry = $registry;
    }

    public function execute(Observer $observer)
    {
        if ($observer->getFullActionName() !== self::ACTION_NAME) {
            return;
        }

        $category = $this->registry->registry('current_category');
        $current_category = $category->getId();
        $categoryLevel = $category->getlevel();
        //echo $categoryLevel."<br>";
        $categoryUrlKey = $category->getUrlKey();
        //echo $categoryUrlKey."<br>";
        $layout = $observer->getLayout();
        //$categoryViewBlock = $layout->getBlock('category.products.list');

        // if($category->getlevel() == 2){
        //     $layout->getUpdate()->addHandle('catalog_category_view_id_32');
        //     //echo "hello";
        //     // $categoryViewBlock = $layout->getBlock('category.products.list');
        //     // return $categoryViewBlock->setTemplate("CP_Categorylist::kitchencabinets/category/shop_cabinets.phtml");
        // }
        // if($category->getlevel() == 3){
        //     echo "hello";
        //     if($categoryUrlKey == "kitchen-cabinets"){
        //         echo "done";
        //     }
        //     if($categoryUrlKey == "bathroom-cabinets"){
        //         echo "bathroom";
        //     }
        //     if($categoryUrlKey == "cabinet-doors-sample-sample"){
        //          echo "bathroom1";
        //     }
        //     if($categoryUrlKey == "decorative-hardware"){
        //          echo "bathroom2";
        //     }

        // }
        if($category->getlevel() == 4){
            //$url_key = array("","","","");
            $categorys = $this->category->create()
                              ->getCollection()
                              ->addAttributeToFilter('url_key',"kitchen-cabinets")
                              ->addAttributeToSelect('*');
            $cat_id = $categorys->getFirstItem()->getEntityId();

            $category = $this->category->create()->load($cat_id);
            $childrenCategories = $category->getChildrenCategories();
            $subCatId = array();
            foreach($childrenCategories as $subcategorie) {
                $subCatId[] = $subcategorie->getId();
            }
            if(in_array($current_category, $subCatId)){
                $layout->getUpdate()->addHandle('catalog_category_view_category_kitchencabinets');
                //echo $current_category;
            }

            $categorys = $this->category->create()
                              ->getCollection()
                              ->addAttributeToFilter('url_key',"bathroom-cabinets")
                              ->addAttributeToSelect('*');
            $cat_id = $categorys->getFirstItem()->getEntityId();

            $category = $this->category->create()->load($cat_id);
            $childrenCategories = $category->getChildrenCategories();
            $subCatId = array();
            foreach($childrenCategories as $subcategorie) {
                $subCatId[] = $subcategorie->getId();
            }
            if(in_array($current_category, $subCatId)){
                $layout->getUpdate()->addHandle('catalog_category_view_category_bathroomcabinets');
            }

            $categorys = $this->category->create()
                              ->getCollection()
                              ->addAttributeToFilter('url_key',"decorative-hardware")
                              ->addAttributeToSelect('*');
            $cat_id = $categorys->getFirstItem()->getEntityId();

            $category = $this->category->create()->load($cat_id);
            $childrenCategories = $category->getChildrenCategories();
            $subCatId = array();
            foreach($childrenCategories as $subcategorie) {
                $subCatId[] = $subcategorie->getId();
            }
            if(in_array($current_category, $subCatId)){
                $layout->getUpdate()->addHandle('catalog_category_view_category_decorativehardwarecabinets');
            }

            $categorys = $this->category->create()
                              ->getCollection()
                              ->addAttributeToFilter('url_key',"cabinet-accessories")
                              ->addAttributeToSelect('*');
            $cat_id = $categorys->getFirstItem()->getEntityId();

            $category = $this->category->create()->load($cat_id);
            $childrenCategories = $category->getChildrenCategories();
            $subCatId = array();
            foreach($childrenCategories as $subcategorie) {
                $subCatId[] = $subcategorie->getId();
            }
            if(in_array($current_category, $subCatId)){
                $layout->getUpdate()->addHandle('catalog_category_view_category_kitchen_accessories');
            }
        }
        return $this;
    }
}